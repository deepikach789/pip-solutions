/*package dao;

public class EmployeeDaoTest {

}
*/
package dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;


public class EmployeeDaoTest {

	@Test
	public void setMapTest() {
HashMap map=new HashMap();
List l=new ArrayList();
	//	EmployeeDao dao=new EmployeeDao();
		//dao.setMap(map);
		assert(map instanceof HashMap) ;
		
		
	}



}
