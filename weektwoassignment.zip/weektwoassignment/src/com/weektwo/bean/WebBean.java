package com.weektwo.bean;

public class WebBean {

	private int billamount;
	private double discount;
	private String user;
	private String storeEmployee;
	private String appliateUser;
	private String twoyearsCustomer;
	public WebBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public WebBean(int billamount, double discount, String user) {
		super();
		this.billamount = billamount;
		this.discount = discount;
		this.user = user;
	}
	
	
	public WebBean(int billamount, double discount, String user, String storeEmployee, String appliateUser,
			String twoyearsCustomer) {
		super();
		this.billamount = billamount;
		this.discount = discount;
		this.user = user;
		this.storeEmployee = storeEmployee;
		this.appliateUser = appliateUser;
		this.twoyearsCustomer = twoyearsCustomer;
	}
	public WebBean(int billamount) {
		this.billamount = billamount;
		
		
	}
	public WebBean(String user, double discount) {
		this.discount = discount;
		this.user = user;
		
	}
	public int getBillamount() {
		return billamount;
	}
	public void setBillamount(int billamount) {
		this.billamount = billamount;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	
}
