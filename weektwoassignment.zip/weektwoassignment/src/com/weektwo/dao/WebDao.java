package com.weektwo.dao;

import com.weektwo.bean.WebBean;

public class WebDao {
	
	WebBean webBEanObj;

	public void totalBill() {
			
	}

}
