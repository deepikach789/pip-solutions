package com.weektwo.service;

import com.weektwo.bean.WebBean;
import com.weektwo.dao.WebDao;
import com.weektwo.UI.WebModules;

public class WebService {
	
	WebDao webDaoObj= new WebDao();

	public void billamount(WebBean webBeanObjBill) {
		 webDaoObj.totalBill( );
		
		}

	public void discount(WebBean webBeanDisObj) {
		
		Object user = null;
		Object storeEmployee = null;
		Object appliateUser = null;
		Object twoyearsCustomer = null;
		if(user==storeEmployee) {
			
			int discount = (30);
			
		}else if(user==appliateUser){
			
			int discount=(10);
		}
		else if (user==twoyearsCustomer){
			int discount=(5);
		}
		
		
		
		
	}

}
