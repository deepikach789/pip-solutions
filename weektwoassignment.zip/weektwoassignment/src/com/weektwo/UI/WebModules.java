package com.weektwo.UI;

import java.util.Scanner;


import com.weektwo.service.WebService;
import com.weektwo.bean.WebBean;

public class WebModules {
	
	WebService webServiceObj=new WebService();
	Scanner scanner=new Scanner(System.in);
	
	public void billAmount() {
		
		System.out.print("Enter bill amount: ");
		int billamount=amountCheck(scanner.nextInt());
		
		WebBean webBeanObjBill=new WebBean(billamount);
		webServiceObj.billamount(webBeanObjBill);
		}
	
	    public void discount() {
		
		System.out.println("enter the type of the user: \n 1.storeEmployee \n 2. affliateUser  \n 3.twoyearsCustomer");
		String user=scanner.next();
		
		
		double discount=scanner.nextDouble();
		
		WebBean webBeanDisObj=new WebBean(user,discount);
		
		webServiceObj.discount(webBeanDisObj);
		
	}
	
	private int amountCheck(int billamount) {
		while(true) {
			if(billamount<=0) {
				System.out.println("Amount should be greater than 0.");
				System.out.println("Enter again: ");
				billamount = scanner.nextInt();
			}
			else {
				return billamount;
			}
		}
		
	}

}
