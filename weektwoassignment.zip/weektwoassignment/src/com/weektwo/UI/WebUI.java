package com.weektwo.UI;

import java.util.Scanner;

public class WebUI {
	public static void main(String args[]) {
		Scanner scanner =new Scanner(System.in);
		int ch;
		char choice;
		
		WebModules webModulesObj=new WebModules();
		do {
			System.out.println("1.enter the bill amount \n  2.enter the employee type \n 3.exit ");
			System.out.print("Enter your choice : ");
			ch = scanner.nextInt();
			switch(ch) {
			case 1:
				webModulesObj.billAmount();
				break;
			case 2:
				webModulesObj.discount();
				break;
			case 3:
				System.exit(0);
				
				System.out.print("Do you want to continue (y/n)...? : ");
				choice = scanner.next().charAt(0);
				if(choice == 'y' || choice=='Y')
					continue;
				else {
					System.out.println("Thank You !");
					System.exit(0);
				}
			} 
		}while(ch != 3 );
		scanner.close();
	}
}


		
	

				
		
	
