package com.weekone;

public class Loan extends Transaction {
	private String loanId;
	private String loanType;
	private double loanAmount;
	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Loan(String loanId, String loanType, double loanAmount) {
		// TODO Auto-generated constructor stub
	}
	
	public String getLoanId() {
		return loanId;
	}
	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		if (loanType.equals("home")||loanType.equals("car")||loanType.equals("education"))
		this.loanType = loanType;
		else
			this.loanType=null;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	
public void getLoan() {
	
}
 
public void showLoanDetails(Loan loan) {
	
	System.out.println(loan.loanId);
	System.out.println(loan.loanType);
	System.out.println(loan.loanAmount);
}
}
