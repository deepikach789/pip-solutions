package com.weekone;

import com.weekone.Loan;
import com.weekone.Account;

public class Transaction {
	private double amount;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(double amount) {
		super();
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void showDetails(Loan loan) {
		
		
	
	}

	public void payLoan(double loanAmount, String loanId, Loan[] loan) {
		
		Loan loan2= new Loan();
		for(int i=0; i<10;i++) {
			if(loanId.equals(loan[i].getLoanId()))
				amount=loan[i].getAmount()+amount;
			loan[i].setAmount(loanAmount);
			System.out.println("the loan has been deposited");
			
		}
			
	}

	public void depositAmount(double amount, String accId, Account[] account) {
		for(int i=0;i<10;i++) {
			if(accId.equals(account[i].getAccId()))
				amount=account[i].getAmount()+amount;
			account[i].setAmount(amount);
			System.out.println("the amount is deposited");
			
				
		}
		
	}

	public void withDraw(double withdrawamount, String accId, Account[] account) {
		
		for(int i=0; i<10;i++) {
			if(accId.equals(account[i].getAccId())) {
				amount=account[i].getAmount()-amount;
				account[i].setAmount(withdrawamount);
				System.out.println("the amount has been withdrawn");
				
	
			}
		}
		
	}

	public void showDetails(Account account) {
		
		
	}


	


	

	
	
	

}
