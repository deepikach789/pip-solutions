package com.weekone;

public class Account extends Loan{
	
	private String accId;
	private String accName;
	private String address;
	private double amount;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String accId, String accName, String address, double amount) {
		super();
		this.accId = accId;
		this.accName = accName;
		this.address = address;
		this.amount = amount;
	}
	public String getAccId() {
		return accId;
	}
	public void setAccId(String accId) {
		this.accId = accId;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public void showDetails() {
		
	}

	public void getDetails( Account account) {
		System.out.println(account.getAccId());
		System.out.println(account.getAccName());
				System.out.println(account.getAddress() );
						System.out.println(account.getAmount());
		
		
	}
	
}
