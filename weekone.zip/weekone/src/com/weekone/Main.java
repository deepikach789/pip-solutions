package com.weekone;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.weekone.Loan;
import com.weekone.Transaction;
import com.weekone.Account;

public class Main {
 

public static void main(String args[]) {
	Account account[]=new Account[10];
	 Scanner scanner=new Scanner(System.in);
	 Loan[] loans= new Loan[10];
		Transaction transaction= new Transaction();
		Loan loan= new Loan();
		
		int choice=0;
		String cont=null;
		do {
		do {
		System.out.println("1. Create Account 2. Login");
		 choice=scanner.nextInt();
		
		switch (choice) {
		case 1:
			
			String accName=null;
			String accountId=null;
			
			int i=0;
			do {
				System.out.println("enter your Name: ");
			 accName=scanner.next();
			}
			while(!validateName(accName));
			System.out.println("Address: ");
			String address=scanner.next();
			System.out.println("Enter deposit ammount: ");
			double amount=scanner.nextDouble();
			String loanType=null;
			double loanAmount=0;
			String choice1=null;
			accountId=getAccountId();
			for(i=0;i<10;i++) {
				String accId = null;
				account[i]=new Account(accId,accName,address,amount);
			}
			System.out.println("Account created successfully with accountId: "+accountId);
			
			break;
		
		case 2:
			String accntId=null;
			int choice2=0;
			Account acc1=null;
			do {
				
			System.out.println("Enter accountId: ");
			
			 accntId=scanner.next();
			}while(!validateaccntId(accntId));
			for(int j=0;j<10;j++) {
				if(accntId.equals(account[j].getAccId())) {
					acc1=account[j];}
				
					else{
						System.out.println("Account does not exist");
						break;
						}
					}
			
			do {
			System.out.println("1. Account Details 2. Loan 3. Transaction");
			choice2=scanner.nextInt();
			switch (choice2) {
			case 1:
				transaction.showDetails(acc1);
				
				break;
			case 2:
				int ch1=0;
				do {
					System.out.println("1. Apply Loan 2. Pay loan 3. Loan details");
					ch1=scanner.nextInt();
					Loan loan1=null;
					switch (ch1) {
					case 1:do {
						System.out.println("Enter loan type: "); 
						loanType=scanner.next();
						 }while(validateLoan(loanType));
					System.out.println("Enter loan amount: ");
						  loanAmount=scanner.nextDouble(); 
						  String loanId=getAccountId();
						  System.out.println("Loan Created with loan Id: "+loanId);
						  for (int j = 0; j < loans.length; j++) {
							loans[j]=new Loan(loanId,loanType,loanAmount);
						}
						break;

					case 2:String loanId1=null;
						do {
						System.out.println("Enter loan Id");
						 loanId1=scanner.next();
					}while(!validateaccntId(loanId1));
						
						for(int j=0;j<10;j++) {
							if(loanId1.equals(loans[j].getLoanId())) {
								loan1=loans[j];}
							
								else{
									System.out.println("Account does not exist");
									break;
									}
								}
						System.out.println("Enter amount: ");
						double loanAmount1=scanner.nextDouble();
						transaction.payLoan(loanAmount1, loanId1, loans);
						break;
					case 3:
						transaction.showDetails(loan1);
						break;
					default:
						break;
					}
				} while (!(ch1<=1&&ch1>=3));
				
				break;
			case 3:int ch=0;
				do {
					System.out.println("1. deposit 2. withdraw 3. show balance");
				 ch=scanner.nextInt();
			
				
				
				switch (ch) {
				case 1:
					System.out.println("Enter amount to be deposited: ");
					double amount1=scanner.nextDouble();
					transaction.depositAmount(amount1, accntId, account);
					
					break;
				case 2:
					System.out.println("Enter amount to be withdraw: ");
					double withdrawamount=scanner.nextDouble();
					transaction.withDraw(withdrawamount, accntId, account);
					
					break;
				case 3:
					System.out.println(acc1.getAmount());
					break;

				
				}
			}while(!(ch>=1&&ch<=3));
				

			
			}
			}while(!(choice>=1&&choice<=3));
			
		
		

		
		}
		System.out.println("Please enter yes to continue: ");
		cont=scanner.next();}
		
		while(!(choice>=1&&choice<=2));
		
		
		}while(cont.equalsIgnoreCase("yes"));

	}

	private static boolean validateLoan(String loanType) {
	
		System.out.println("enter the type of loan: "+loanType);
		return false;
		
		}


	private static boolean validateaccntId(String accntId) {
		
		boolean flag= false;
		String regex="^[0-9]{7}-ASDF$";
			Pattern p= Pattern.compile(regex);
			Matcher m= p.matcher(accntId);
			if(!m.matches())
			{
			System.out.println("Please Enter valid accountId");
			return false;
			}
			else
		return true;

 		}

private static String getAccountId() {
	// TODO Auto-generated method stub
	long accountNo=(long)(Math.random()*10000000);
	String actId=Long.toString(accountNo);
	actId=actId+"-ASDF";
	return actId;
}

private static boolean validateName(String accName) {
	
	String regex = "[A-Z]{1}[a-zA-Z]{2,}";
	Pattern p = Pattern.compile(regex);
	Matcher m = p.matcher(accName);
	if (!m.matches()) {
		System.out.println("Name must start with a capital letter");
		return false;
	}
	return true;

}
		}
		
		
